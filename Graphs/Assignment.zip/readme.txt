run instructions
g++ <file-name> -std=c++11